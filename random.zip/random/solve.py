from sympy import solve
from sympy import symbols

x = symbols("x")
y = symbols("y")